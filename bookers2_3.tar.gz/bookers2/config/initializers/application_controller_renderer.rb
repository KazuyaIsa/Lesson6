# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = 'f9e7ca510e0399f322d4ee4e637dad5f634e72ae90309c8de6b366e5a7efbf035749dc2f6ac71c41fe495143e2de1e6a62c57de8a50c166f5a8d3ee442c39477'